var a=540;
        document.write("value of a",a);
        console.log("value of a",a);
        
        