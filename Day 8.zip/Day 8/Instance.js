//typeof
//Array Instance of
var a = ["check", "it"];

document.write(a instanceof Array);

document.write(a instanceof Number);

document.write("<br/>");